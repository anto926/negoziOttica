package it.corso.dao;

import org.springframework.data.repository.CrudRepository;

import it.corso.model.Occhiale;

public interface OcchialeDao extends CrudRepository<Occhiale, Integer>{

}
