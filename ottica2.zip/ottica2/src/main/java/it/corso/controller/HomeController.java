package it.corso.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import it.corso.model.Occhiale;
import it.corso.service.OcchialeService;

@Controller
@RequestMapping(path = {"/", "/index", "/home"})
public class HomeController {
	
	@Autowired
	private OcchialeService occhialeService;

	@GetMapping
	public String getpage(Model model) {
		Occhiale occhiale1 = occhialeService.getOcchialeById(14);
		Occhiale occhiale2 = occhialeService.getOcchialeById(19);
		Occhiale occhiale3 = occhialeService.getOcchialeById(16);
		Occhiale occhiale4 = occhialeService.getOcchialeById(17);
		Occhiale occhiale5 = occhialeService.getOcchialeById(20);
		Occhiale occhiale6 = occhialeService.getOcchialeById(12);
		Occhiale occhiale7 = occhialeService.getOcchialeById(23);
		Occhiale occhiale8 = occhialeService.getOcchialeById(24);
		Occhiale occhiale9 = occhialeService.getOcchialeById(25);
		
		model.addAttribute("occh1", occhiale1);
		model.addAttribute("occh2", occhiale2);
		model.addAttribute("occh3", occhiale3);
		model.addAttribute("occh4", occhiale4);
		model.addAttribute("occh5", occhiale5);
		model.addAttribute("occh6", occhiale6);
		model.addAttribute("occh7", occhiale7);
		model.addAttribute("occh8", occhiale8);
		model.addAttribute("occh9", occhiale9);

		return "home";
	}
}
