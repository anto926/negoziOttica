package it.corso.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import it.corso.service.OcchialeService;

@Controller
@RequestMapping(path = "/catalogo")
public class CatalogoController {
	
	@Autowired
	private OcchialeService occhialeService;

	//http://localhost:8080/ottica2/catalogo?materiale=
	
	@GetMapping
	public String getPage(Model model, @RequestParam(name = "materiale", required = false) String materiale) {
		
		String uno = "Tutti gli occhiali";
		String due = "Occhiali in " + materiale;
		
		if(materiale == "") {
			model.addAttribute("occhiali", occhialeService.getOcchiali());
			model.addAttribute("stringa", uno);
			return "catalogo";
		}
		else if(materiale != null) {
			model.addAttribute("occhiali", occhialeService.getOcchialiMateriale(materiale));
			model.addAttribute("stringa", due);
			return "catalogo";
		}
			
		model.addAttribute("occhiali", occhialeService.getOcchiali());
		model.addAttribute("materiale", uno);
			//model.addAttribute("occhiali", occhialeService.getOcchialiMateriale("Metallo"));
			//model.addAttribute("occhiali", occhialeService.getOcchialiMateriale("Plastica"));
			//model.addAttribute("occhiali", occhialeService.getOcchialiMateriale("Legno"));
		
		return "catalogo";
	}
	
	
	
}
