package it.corso.controller;

import java.io.File;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import it.corso.model.Occhiale;
import it.corso.service.OcchialeService;

@Controller
@RequestMapping(path = "/dettaglio")
public class DettaglioController {
	
	@Autowired
	private OcchialeService occhialeService;

	@GetMapping
	public String getPage(@RequestParam(name = "id", required = false) Integer id, Model model, HttpSession session) {
		if(id == null) {
			return "redirect:/catalogo";
		}else {
			Occhiale occhiale = occhialeService.getOcchialeById(id);
			String rootDir = session.getServletContext().getRealPath("/");
			String filePath = rootDir + "static\\immagini\\occhiali\\" + occhiale.getId() + ".png";
			File file = new File(filePath);
			occhiale.setImage(file.exists());
			model.addAttribute("occhiale", occhiale);
			model.addAttribute("id", occhiale.getId());
			model.addAttribute("tipologia", occhiale.getTipologia());
			model.addAttribute("modello", occhiale.getModello());
			model.addAttribute("marca", occhiale.getMarca());
			model.addAttribute("descrizione", occhiale.getDescrizione());
			model.addAttribute("prezzo", occhiale.getPrezzo());
			model.addAttribute("genere", occhiale.getGenere());
			model.addAttribute("materiale", occhiale.getMateriale());
			model.addAttribute("colore", occhiale.getColore());
			model.addAttribute("occhialiRandom", occhialeService.occhialiDettaglio());
			return "dettaglio";
		}
		
		
	}
}
