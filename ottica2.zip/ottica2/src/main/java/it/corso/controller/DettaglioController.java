package it.corso.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import it.corso.model.Occhiale;
import it.corso.service.OcchialeService;

@Controller
@RequestMapping(path = "/dettaglio")
public class DettaglioController {
	
	@Autowired
	private OcchialeService occhialeService;

	@GetMapping
	public String getPage(@RequestParam(name = "id", required = false) Integer id, Model model) {
		if(id == null) {
			return "redirect:/catalogo";
		}else {
			Occhiale occhiale = occhialeService.getOcchialeById(id);
			model.addAttribute("id", occhiale.getId());
			model.addAttribute("tipologia", occhiale.getTipologia());
			model.addAttribute("modello", occhiale.getModello());
			model.addAttribute("marca", occhiale.getMarca());
			model.addAttribute("descrizione", occhiale.getDescrizione());
			model.addAttribute("prezzo", occhiale.getPrezzo());
		}
		
		return "dettaglio";
	}
}
