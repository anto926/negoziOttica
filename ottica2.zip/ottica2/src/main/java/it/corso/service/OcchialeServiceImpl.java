package it.corso.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoField;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.corso.dao.OcchialeDao;
import it.corso.model.Occhiale;

@Service
public class OcchialeServiceImpl implements OcchialeService{
	
	@Autowired
	private OcchialeDao occhialeDao;

	@Override
	public String codiceSconto() {
		char carattere;
		String iD = "";
		for (int i = 0; i < 2; i++){
            carattere = (char)(Math.random()*26 + 65); 
            iD += carattere;
        }
        
        for (int i = 0; i < 4; i++){
            carattere = (char)(Math.random()*10 + 48);
            iD += carattere;
        }
		return iD;
	}

	@Override
	public Occhiale getOcchialeById(int id) {
		return occhialeDao.findById(id).get();
	}

	@Override
	public List<Occhiale> getOcchiali() {
		return (List<Occhiale>) occhialeDao.findAll();
	}

	@Override
	public void deleteOcchiale(Occhiale occhiale) {
		occhialeDao.delete(occhiale);	
	}

	@Override
	public void createOcchiale(Occhiale occhiale) {
		occhialeDao.save(occhiale);
	}

	@Override
	public double applicaSconto(double prezzo) {
		double sconto;
		sconto = prezzo - ((prezzo / 100) * 20);
		return sconto;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Occhiale> getOcchialiMateriale(String materiale) {
		return (List<Occhiale>) occhialeDao.findByMateriale(materiale);
	}

	@Override
	public String orarioCoupon() {
		LocalDateTime c = LocalDateTime.now();
		DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		return c.format(formatter2);
	}

	@Override
	public List<Occhiale> occhialiDettaglio() {
		List<Occhiale> tuttiOcchiali = this.getOcchiali();
		List<Occhiale> occhialiRandom = new ArrayList<>();
		ArrayList<Integer> casuali = new ArrayList<>();
		
		while(casuali.size() < 3) {
			int random = new Random().nextInt(tuttiOcchiali.size()) + 1;
			if(!casuali.contains(random)) {
				casuali.add(random);
			}
		}
		
		for(int i = 0; i < casuali.size(); i++) {
			occhialiRandom.add(this.getOcchialeById(casuali.get(i)));
		}
		
		return occhialiRandom;
	}

	@Override
	public Occhiale getLastOcchiale() {
		return occhialeDao.findFirstByOrderByIdDesc();
	}

	@Override
	public List<Occhiale> getOcchialiMarca(String marca) {
		return occhialeDao.findByMarca(marca);
	}

	@Override
	public List<Occhiale> getOcchialiGenere(String genere) {
		return occhialeDao.findByGenere(genere);
	}

	@Override
	public List<Occhiale> getOcchialiColore(String colore) {
		return occhialeDao.findByColore(colore);
	}

	@Override
	public int getLastId() {
		return occhialeDao.getLastId();
	}

	@Override
	public List<Occhiale> getOcchialiTipologia(String tipologia) {
		return occhialeDao.findByTipologia(tipologia);
	}
	
	
}
